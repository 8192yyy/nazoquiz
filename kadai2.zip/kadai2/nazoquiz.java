import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Timer;
import java.util.TimerTask;
import javax.imageio.ImageIO;

/**
 * 暇つぶし時計アプリケーション。
 * 時間と分ごとに画像を表示します。
 */
public class nazoquiz extends JFrame {
    private JLabel hourlyLabel; // 時間表示用のラベル
    private JLabel minutelyLabel; // 分表示用のラベル

    private ImageIcon[] hourlyIcons; // 時間ごとのアイコン
    private ImageIcon[] minutelyIcons; // 分ごとのアイコン

    private static final int IMAGE_WIDTH = 300; // 画像の幅
    private static final int IMAGE_HEIGHT = 300; // 画像の高さ

    /**
     * コンストラクタ。
     * アプリケーションの初期化を行います。
     */
    public nazoquiz() {
        setTitle("暇つぶし時計(左が時間で右が分)");
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        hourlyLabel = new JLabel();
        minutelyLabel = new JLabel();

        add(hourlyLabel);
        add(minutelyLabel);

        initializeImages();

        // 1秒ごとに画像を更新するタイマーを開始
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                updateImages();
            }
        }, 0, 1000);

        setVisible(true);
    }

    /**
     * 画像を初期化します。
     */
    private void initializeImages() {
        hourlyIcons = new ImageIcon[24];
        for (int i = 0; i < 24; i++) {
            hourlyIcons[i] = loadAndResizeIcon("Image1/MicrosoftTeams-image (" + i + ").png");   
        }

        minutelyIcons = new ImageIcon[60];
        for (int i = 0; i < 60; i++) {
            minutelyIcons[i] = loadAndResizeIcon("Image2/MicrosoftTeams-image (" + i + ").png");
        }
    }

    /**
     * 指定されたパスから画像を読み込み、リサイズして返します。
     * @param path 画像ファイルのパス
     * @return リサイズされた画像のアイコン
     */
    private ImageIcon loadAndResizeIcon(String path) {
        try {
            BufferedImage originalImage = ImageIO.read(new File(path));
            Image resizedImage = originalImage.getScaledInstance(IMAGE_WIDTH, IMAGE_HEIGHT, Image.SCALE_SMOOTH);
            return new ImageIcon(resizedImage);
        } catch (IOException e) {
            // 画像の読み込みに失敗した場合はnullを返す
            return null;
        }
    }

    /**
     * 現在の時刻に応じて画像を更新します。
     */
    private void updateImages() {
        SwingUtilities.invokeLater(() -> {
            LocalDateTime now = LocalDateTime.now();
            int hour = now.getHour();
            int minute = now.getMinute();

            // 時間と分に対応するアイコンを設定
            hourlyLabel.setIcon(hourlyIcons[hour % 24]);
            minutelyLabel.setIcon(minutelyIcons[minute % 60]);
        });
    }

    /**
     * アプリケーションのエントリーポイント。
     * @param args コマンドライン引数
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(nazoquiz::new);
    }
}
